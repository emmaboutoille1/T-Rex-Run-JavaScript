var jump = false;
var direction = 1; //the force of gravity in the y direction
var velocity = 10; // the speed of the player
var jumpPower = 20; //the energy or strength of player
var fallingSpeed = 11.5; //speed of the dino when falling to the ground
var minHeight = 200; //height of ground
var maxHeight = -30; //height of sky
var jumpCounter = 0; //keeps track of how much dino is jumping

function gravity() { //start of function gravity
	if(dinoY >= minHeight && jump == false){ //if statement stating that if dinoY is greater than or equal to minHeight and if jump equals false
		dinoY = dinoY //make dinoY equal to dinoY
		jumpCounter = 0; //make jumpCounter equal to 0
	}
	else{ //else if there is another condition
	  dinoY = dinoY + (direction*velocity); //make dinoY equal to dinoY + the direction times the velocity
 }
	
	if(jump == true){ //if statement stating that if jump is equal to true
		if(dinoY <= maxHeight || jumpCounter >= jumpPower){ //if statement stating that if dinoY is less than or equal to maxHeight or if jumpCounter is greater than or equal to jumpPower
			velocity = fallingSpeed; //make velocity equal to fallingSpeed
		}
		else{ //else if there is another condition
		 velocity = -jumpPower; //make velocity equal to negative jumpPower
		 jumpCounter += jumpCounter; //make jumpCounter equal to jumpCounter + 1
		}
	}
	else{ //else if there is another condition
		velocity = fallingSpeed; //make velocity equal to fallingSpeed
	}
} //end of function gravity
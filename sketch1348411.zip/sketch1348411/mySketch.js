var score = 0; //variable representing the player's score
var dinoX = -150; //x value of dino image
var dinoY = 220; //y value of dino image
var x1 = 0; //x value of first desert background image
var x2; //x value of second desert background image
var x3; //x value of first cactus
var x4; //x value of second cactus
var x5; //x value of third cactus
var scrollSpeed = 7; //speed that the background moves at
var myRans1 = []; //variable used to make and display the cacti
var mode; //variable used to create the different screens in the game

function setup() { //start of function setup
	createCanvas(800,500); //dimensions of canvas
	x2 = width; //value of x2 variable
	x4 = width; //value of x4 variable
	x3 = 250; //value of x3 variable
	x5 = 1300; //value of x5 variable
	makeCacti1(); //call on function makeCacti1
	makeCacti2(); //call on function makeCacti2
	makeCacti3(); //call on function makeCacti3
	mode = 0; //the game has not started
	answer = prompt("Would you like to have music? (yes/no)"); //asks user if they want music playing in the background
	if(answer == "y" || answer == "yes" || answer == "Yes" || answer == "YES"){ //if statement stating that if user answers yes
		music.loop() //allows music to play continuously
		music.setVolume(0.2) //sets music volume to 0.2
	}
} //end of function setup
	
function preload() { //start of function preload
  dino = loadImage('T Rex.png'); //load dino image
	cactus = loadImage('cactus2.png') //load cactus image
	desertBackground1 = loadImage('desertBackground1.jpeg'); //load first desert background image
	desertBackground2 = loadImage('desertBackground2.jpeg') //load second desert background image
	homeScreenBackground = loadImage('home screen background image.jpeg'); //load home screen image
	gameOver = loadImage('game over.jpeg'); //load game over image
	music = loadSound('gameMusic.mp3'); //load music
} //end of function preload

function draw() { //start of function draw
	clear(); //clear screen
	if(mode == 0){ //if statement stating that if mode is equal to 0
		background(homeScreenBackground); //home screen background image
	}
	
	if(mode == 1){ //if statement stating that if mode is equal to 1
	 background(255); //set background colour to white
	 fill(0); //set text colour to black
	 textSize(24); //set text size to 24
	 text("Game Instructions",300,40); //display text on screen
	 text("Click the spacebar or the up arrow to jump",180,120); //display text on screen
	 text("Do your best to avoid the cacti",250,180); //display text on screen
	 text("To play the background music press the 'p' key",170,240); //display text on screen
	 text("To pause the music press the 'o' key",220,300); //display text on screen
	 text("Are you ready to play?",280,360); //display text on screen
	 text("Click the right arrow to continue",230,420); //display text on screen
	}
	
	if(mode == 2){ //if statement stating that is mode is equal to 2
	 clear(); //clear screen
	 image(desertBackground1, x1, 0, width, height); //display first desert background image on screen
   image(desertBackground2, x2, 0, width, height); //display second desert background image on screen
	 displayCacti1(); //call on function displayCacti1
	 displayCacti2(); //call on function displayCacti2
	 displayCacti3(); //call on function displayCacti3
	 image(dino,dinoX,dinoY,850,700); //display dino image on screen
	 fill(0); //set text colout to black
	 textSize(40); //set text size to 40
	 text("Click the 's' key to start the game",120,230); //display text on screen
	 gravity(); //call on function gravity
	 dinoCollision(); //call on function dinoCollision
	 playerScore(); //call on function playerScore
	}
	
	if(mode == 3){ //if statement stating that is mode is equal to 3
	 clear(); //clear screen
	 image(desertBackground1, x1, 0, width, height); //display first desert background image on screen
   image(desertBackground2, x2, 0, width, height); //display second desert background image on screen
	 displayCacti1(); //call on function displayCacti1
	 displayCacti2(); //call on function displayCacti2
	 displayCacti3(); //call on function displayCacti3
	 image(dino,dinoX,dinoY,850,700); //display dino image on screen
	 gravity(); //call on function gravity
	 dinoCollision(); //call on function dinoCollision
	 playerScore(); //call on function playerScore
  
   x1 -= scrollSpeed; //subtract scrollSpeed from x1
   x2 -= scrollSpeed; //subtract scrollSpeed from x2
  
   if (x1 < -width){ //if statement stating that if x1 is less than negative width
     x1 = width; //make x1 equal to width
   }
   if (x2 < -width){ //if statement stating that if x2 is less than negative width
     x2 = width; //make x2 equal to width
   }
	
	 x3 -= scrollSpeed; //subtract scrollSpeed from x3
   x4 -= scrollSpeed; //subtract scrollSpeed from x4
	 x5 -= scrollSpeed; //subtract scrollSpeed from x5
  
   if (x3 < -width){ //if statement stating that if x3 is less than negative width
     x3 = width; //make x3 equal to width
   }
   if (x4 < -width){ //if statement stating that if x4 is less than negative width
     x4 = width; //make x4 equal to width
   }
	 if (x5 < -width){ //if statement stating that if x5 is less than negative width
     x5 = width; //make x5 equal to width
   }
	 
	 if(dinoY < maxHeight){ //if statement stating that if dinoY is less than maxHeight
			jump = false; //make jump equal to false
		}
		
	 fill(0); //set text colour to black
	 textSize(24); //set text size to 24
	 text("No Internet",430,40) //display text on screen
	 textSize(16); //set text size to 16
	 text("Try: ",430,70); //display text on screen
	 text("Checking the network cables modem, and router",430,100); //display text on screen
   text("Reconnecting to Wi-Fi",430,130); //display text on screen
	 text("ERR_INTERNET_DISCONNECTED",430,180); //display text on screen
	 textSize(24); //set text size to 24
	 text("Score: " + score, 10, 40); //display text on screen
	}
	
	if(mode == 4){ //if statement stating that is mode is equal to 4
		background(gameOver); //display game over background on screen
		fill(255); //set text colour to white
		text("click the left arrow to play again", 240, 400); //display text on screen
		score = 0; //reset score variable to 0
		x3 = 430; //set x value of first cactus to 430
		x4 = 900; //set x value of second cactus to 900
		x5 = 1450; //set x value of thirs cactus to 1450
	}
	
} //end of function draw



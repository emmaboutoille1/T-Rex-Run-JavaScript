function dinoCollision() {
  if(dinoX >= x4-190 && dinoX <=x4-140 && dinoY > maxHeight+220 || dinoX >= x3-200 && dinoX <=x3-140 && dinoY > maxHeight+220 || dinoX >= x5-190 && dinoX <=x5-140 && dinoY > maxHeight+220){ //collision code for when dino hits a cactus
		mode = 4; //make mode equal to 4
	}
}
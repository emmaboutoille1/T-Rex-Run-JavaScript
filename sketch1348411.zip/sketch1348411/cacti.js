function makeCacti1() {
	
  for (var i = 0; i < 1; i++) { //for loop stating that for when the variable i equals 0 and when is less than 1 and when i is incremented by 1
		var r = 1 //make variable r equal to 1
		myRans1[i] = r; //store variable i in myRans1 and make myRans1 equal to r
		stroke(0); //set stroke colour to black
		image(cactus,x3, 325, 150, 150);//x,y, width, height values of first cactus
  }

}

function makeCacti2() {
	
  for (var i = 0; i < 1; i++) { //for loop stating that for when the variable i equals 0 and when is less than 1 and when i is incremented by 1
		var r = 1 //make variable r equal to 1
		myRans1[i] =r; //store variable i in myRans1 and make myRans1 equal to r
		stroke(0); //set stroke colour to black
		image(cactus,x4, 325, 150, 150);//x,y, width, height values of second cactus
  }

}

function makeCacti3() {
	
  for (var i = 0; i < 1; i++) { //for loop stating that for when the variable i equals 0 and when is less than 1 and when i is incremented by 1
		var r = 1 //make variable r equal to 1
		myRans1[i] = r; //store variable i in myRans1 and make myRans1 equal to r
		stroke(0); //set stroke colour to black
		image(cactus,x5, 325, 150, 150);//x,y, width, height
  }

}
	
function displayCacti1() {
	
   for (var i = 0; i < myRans1.length; i++) { //for loop stating that for when the variable i equals 0 and i is less than myRans1.length and when i is incremented by 1
		r = myRans1[i]; //make r equal to myRans1 and store i in myRans1
		stroke(0); //set stroke colour to black
		image(cactus,x3, 325, 150, 150);//x,y, width, height
  }

}

function displayCacti2() {
	
   for (var i = 0; i < myRans1.length; i++) { //for loop stating that for when the variable i equals 0 and i is less than myRans1.length and when i is incremented by 1
		r = myRans1[i]; //make r equal to myRans1 and store i in myRans1
		stroke(0); //set stroke colour to black
		image(cactus,x4, 325, 150, 150);//x,y, width, height
  }

}

function displayCacti3() {
	
   for (var i = 0; i < myRans1.length; i++) { //for loop stating that for when the variable i equals 0 and i is less than myRans1.length and when i is incremented by 1
		r = myRans1[i]; //make r equal to myRans1 and store i in myRans1
		stroke(0); //set stroke colour to black
		image(cactus,x5, 325, 150, 150);//x,y, width, height
  }

}
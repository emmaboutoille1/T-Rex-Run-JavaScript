function keyPressed() { //start of function keyPressed
	
	 if(key == ' ' || keyCode == UP_ARROW){ //if statement stating that if the key pressed is the spacebar or up arrow
	   jump = true; //make jump equal to true
	 }
	 else{ //else if any other key is pressed
		 jump = false; //make jump equal to false
	 }
	
	if(key == 'p'){ //if statement stating that if the key pressed is p
		music.play(); //make the music play
}
	if(key == 'o'){ //if statement stating that if the key pressed is o
		music.pause(); //make the music pause
	}

	if(keyCode === ENTER) { //if statement stating that if the key pressed is the enter key
		mode = 1; //make mode equal to 1
	}
	
	if(keyCode == RIGHT_ARROW) { //if statement stating that if the key pressed is the right arrow
		mode = 2; //make the mode equal to 2
	}
	
	if(key == 's') { //if statement stating that if the key pressed is s
		mode = 3; //make mode equal to 3
	}
	
	if(keyCode == LEFT_ARROW) { //if statement stating that if the key pressed is the left arrow
		score = 0; //make score equal to 0
		mode = 0; //make mode equal to 0
	}
}

function keyReleased() { //start
	 if(key == ' ' || keyCode == UP_ARROW){ //if statement stating that if the key being released is the space bar or the up arrow
		 jump = false; //make jump equal to false
	 }
}
 

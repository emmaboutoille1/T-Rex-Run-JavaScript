function playerScore() {
	if(dinoX != x3-140 && dinoX != x4-140 && dinoX != x5-140 && dinoX < x3+5 && dinoX >x3-5 || dinoX < x4+5 && dinoX >x4-5 || dinoX < x5+5 && dinoX >x5-5){ //if statement stating that if the dino jumps over the cactus without hitting it
		score += 1 //increase the score by 1
	}
}